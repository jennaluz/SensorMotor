/*
 * SensorMotor/include/private/system_error.h
 *
 * Handles all error codes.
 */


#pragma once


#include "system_code.h"


void system_error(system_code error);
