/*
 * SensorMotor/include/private/error.h
 */


#pragma once


#include "system_code.h"


void vError(system_code_e eError);
